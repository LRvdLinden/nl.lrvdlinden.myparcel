'use strict';

const Homey = require('homey');
const fs = require('fs');
const path = require('path');
const PostNLApi = require('../../lib/postnl-api');
const localizePackageStatus = require('../../lib/status-i18n');
const { renderDeliveryCard, renderNoPackageCard, loadDeliveryVan, hhmm } = require('../../lib/delivery-image');

class PostNLDevice extends Homey.Device {
  async onInit() {
    this._latestMailImageId = null;
    this._latestPackageImageState = null;
    this._packageImageCache = new Map();
    this._packageCameraImage = null;
    this._packageImageBuffer = null;
    this._activePackageForImage = null;
    this._packageImageTimer = null;
    this._letterImageCache = new Map();
    this._syncing = null;
    this._storage = {
      get: key => this.getStoreValue(key),
      set: (key, value) => this.setStoreValue(key, value),
      unset: key => this.unsetStoreValue(key),
    };
    this.api = new PostNLApi({ homey: this.homey, log: (...args) => this.log(...args), storage: this._storage });
    const storedSnapshot = this.getStoreValue('snapshot') || { packages: [], updatedAt: null };
    this.snapshot = { ...storedSnapshot, letters: [], liveLetters: [] };
    if ((storedSnapshot.letters || []).length || (storedSnapshot.liveLetters || []).length) {
      await this.setStoreValue('snapshot', { ...storedSnapshot, letters: [], liveLetters: [] });
    }

    await this._ensureCapabilities();
    await this._ensurePackageCameraImage();
    this._startPackageImageRefresh();
    await this.applySnapshot(this.snapshot, null);
    if (this.api.hasCredentials()) this.homey.setTimeout(() => this.sync({ reason: 'device-init' }).catch(this.error), 5000);
  }

  async onUninit() {
    if (this._packageImageTimer) this.homey.clearInterval(this._packageImageTimer);
    this._packageImageTimer = null;
  }

  hasAccountCredentials() { return this.api?.hasCredentials() || Boolean(this.getStoreValue('auth')); }

  async _ensureCapabilities() {
    for (const capability of ['postnl_delivery_date', 'postnl_delivery_window', 'postnl_package_status', 'postnl_package_sender', 'postnl_package_receiver', 'postnl_package_tracking', 'postnl_package_event', 'postnl_package_status_time', 'postnl_package_delivered', 'postnl_package_shipment_type', 'postnl_package_weight', 'postnl_package_dimensions', 'postnl_package_history', 'postnl_package_observation_code', 'postnl_package_canonical_status', 'postnl_package_pickup', 'postnl_package_pickup_type']) {
      if (!this.hasCapability(capability)) await this.addCapability(capability);
    }
  }

  async importLegacyAccount(auth, snapshot) {
    await this.api.replaceAuth(auth);
    if (snapshot) {
      this.snapshot = { ...snapshot, letters: [], liveLetters: [] };
      await this.setStoreValue('snapshot', { ...snapshot, letters: [], liveLetters: [] });
    }
    await this.applySnapshot(this.snapshot, null);
  }

  async updateCredentials(auth, profile = null, loginUsername = '', loginPassword = '') {
    await this.api.replaceAuth(auth);
    if (profile?.username) await this.setStoreValue('username', profile.username);
    if (loginUsername) await this.setStoreValue('login_username', String(loginUsername).trim());
    if (loginPassword) await this.setStoreValue('login_password', String(loginPassword));
    await this.setAvailable().catch(this.error);
    return this.sync({ reason: 'repair-login', force: true });
  }

  async sync({ reason = 'manual', force = false } = {}) {
    if (this._syncing) return this._syncing;
    this._syncing = this._sync({ reason, force }).finally(() => { this._syncing = null; });
    return this._syncing;
  }

  async _sync({ reason }) {
    if (!this.api.hasCredentials()) {
      const error = new Error(this.homey.__('errors.not_authenticated'));
      error.code = 'AUTH_REAUTH_REQUIRED';
      if (!['interval', 'startup', 'device-init', 'midnight'].includes(reason)) throw error;
      return this.snapshot;
    }

    const previous = this.snapshot || { letters: [], liveLetters: [], packages: [] };
    try {
      const live = await this.api.fetchAll();
      // My Post is live-only: keep only the mail items currently returned by PostNL.
      // Images are hydrated for the current response only; removed items are not archived locally.
      const liveLetters = await Promise.all((live.letters || []).map(async item => {
        const next = { ...item };
        if (item.imageUrl) {
          try { next.imageData = await this.api.fetchImage(item.imageUrl); }
          catch (error) { this.log('Live mail image fetch failed', item.id, error.message); }
        }
        return next;
      }));
      const current = {
        letters: liveLetters,
        liveLetters,
        packages: live.packages,
        updatedAt: new Date().toISOString(),
        account: live.account || null,
        mailApiStatus: live.mailApiStatus || 'unknown',
        mailApiError: live.mailApiError || null,
        reason,
      };
      this.snapshot = current;
      await this.setStoreValue('snapshot', { ...current, letters: [], liveLetters: [] });
      await this.handleSnapshotChanges(previous, current);
      if (current.mailApiStatus === 'temporarily_unavailable') {
        const previousMailError = String(previous.mailApiError || '');
        const currentMailError = String(current.mailApiError || 'Mijn PostNL is tijdelijk niet beschikbaar');
        if (previous.mailApiStatus !== 'temporarily_unavailable' || previousMailError !== currentMailError) {
          await this.triggerSyncFailed(currentMailError).catch(this.error);
        }
      }
      await this.setStoreValue('loginExpiredFlowNotified', false);
      await this.applySnapshot(current, null);
      return current;
    } catch (error) {
      const authExpired = error?.code === 'AUTH_REAUTH_REQUIRED' || error?.code === 'AUTH_EXPIRED' || [401, 403].includes(Number(error?.statusCode));
      this.error('[PostNLDevice] sync_failed', JSON.stringify({ reason, ...this.api.safeErrorInfo(error), ...this.api.getAuthDiagnostics() }));
      if (authExpired) {
        const alreadyTriggered = this.getStoreValue('loginExpiredFlowNotified') === true;
        if (!alreadyTriggered) {
          await this.triggerLoginExpired().catch(this.error);
          await this._notifyAuthExpiredOnce().catch(this.error);
          await this.setStoreValue('loginExpiredFlowNotified', true);
        }
      }
      await this.triggerSyncFailed(error.message).catch(this.error);
      // Never expose stale mail when live PostNL retrieval fails.
      const failed = {
        ...previous,
        letters: [],
        liveLetters: [],
        updatedAt: new Date().toISOString(),
        mailApiStatus: 'temporarily_unavailable',
        mailApiError: error.message || String(error),
      };
      this.snapshot = failed;
      await this.setStoreValue('snapshot', { ...failed, letters: [], liveLetters: [] });
      await this.applySnapshot(failed, error);
      throw error;
    }
  }


  async _notifyAuthExpiredOnce() {
    if (this.getStoreValue('authExpiredNotified') === true) return;
    const language = this.homey.i18n.getLanguage();
    const messages = {
      nl: `PostNL opnieuw koppelen – De inloggegevens van ${this.getName()} zijn verlopen. Open het betreffende apparaat en koppel je PostNL-account opnieuw.`,
      de: `PostNL erneut verbinden – Die Anmeldedaten für ${this.getName()} sind abgelaufen. Öffne das Gerät und verbinde dein PostNL-Konto erneut.`,
      fr: `Reconnecter PostNL – Les identifiants de ${this.getName()} ont expiré. Ouvrez l’appareil et reconnectez votre compte PostNL.`,
      it: `Ricollega PostNL – Le credenziali di ${this.getName()} sono scadute. Apri il dispositivo e ricollega il tuo account PostNL.`,
      sv: `Anslut PostNL igen – Inloggningsuppgifterna för ${this.getName()} har gått ut. Öppna enheten och anslut ditt PostNL-konto igen.`,
      no: `Koble til PostNL på nytt – Påloggingsinformasjonen for ${this.getName()} har utløpt. Åpne enheten og koble til PostNL-kontoen på nytt.`,
      es: `Volver a conectar PostNL – Las credenciales de ${this.getName()} han caducado. Abre el dispositivo y vuelve a conectar tu cuenta PostNL.`,
      da: `Forbind PostNL igen – Loginoplysningerne til ${this.getName()} er udløbet. Åbn enheden og forbind din PostNL-konto igen.`,
      ru: `Повторно подключите PostNL – Учетные данные ${this.getName()} истекли. Откройте устройство и повторно подключите аккаунт PostNL.`,
      pl: `Połącz PostNL ponownie – Dane logowania dla ${this.getName()} wygasły. Otwórz urządzenie i połącz konto PostNL ponownie.`,
      ko: `PostNL 다시 연결 – ${this.getName()}의 로그인 정보가 만료되었습니다. 기기를 열고 PostNL 계정을 다시 연결하세요.`,
      ar: `أعد ربط PostNL – انتهت صلاحية بيانات تسجيل الدخول الخاصة بـ ${this.getName()}. افتح الجهاز وأعد ربط حساب PostNL.`,
      en: `Reconnect PostNL – The credentials for ${this.getName()} have expired. Open the affected device and reconnect your PostNL account.`,
    };
    const excerpt = messages[language] || messages.en;
    await this.homey.notifications.createNotification({ excerpt });
    await this.setStoreValue('authExpiredNotified', true);
  }

  _flowDriver() {
    return this.driver || this.homey.drivers.getDriver('postnl');
  }

  async _triggerDeviceFlow(cardId, tokens = {}, state = {}) {
    return this._flowDriver().triggerDeviceFlow(cardId, this, tokens, state);
  }

  async triggerNewMail(tokens = {}) { return this._triggerDeviceFlow('new_mail', tokens); }
  async triggerNewPackage(tokens = {}) { return this._triggerDeviceFlow('new_package', tokens); }
  async triggerDeliveryWindowKnown(tokens = {}) { return this._triggerDeviceFlow('delivery_window_known', tokens); }
  async triggerPackageStatusChanged(tokens = {}) { return this._triggerDeviceFlow('package_status_changed', tokens); }
  async triggerSyncFailed(message = '') { return this._triggerDeviceFlow('sync_failed', { error: String(message || '') }); }
  async triggerLoginExpired() { return this._triggerDeviceFlow('login_expired', {}); }

  async _packageTokens(parcel = {}) {
    const packageImage = await this.getPackageDeliveryImage(parcel).catch(() => null);
    const status = String(parcel.statusRaw || parcel.latestStatusEvent || parcel.status || localizePackageStatus(this.homey, parcel.status) || '').trim();
    const deliveryDate = parcel.deliveryDate ? this.api.formatDateDMY(parcel.deliveryDate) : '';
    const deliveryWindow = parcel.deliveryWindow || this.api.formatWindow(parcel.deliveryWindowFrom, parcel.deliveryWindowTo) || '';
    const sender = parcel.sender || parcel.title || '';
    const tracking = parcel.barcode || parcel.id || '';
    const statusRaw = String(parcel.statusRaw || parcel.status || status || '');
    const statusEventTime = parcel.statusChangedAt ? this.api.formatDateTime(parcel.statusChangedAt) || String(parcel.statusChangedAt) : '';
    const tokens = {
      id: parcel.id || '', sender, receiver: parcel.receiver || '',
      title: parcel.title || parcel.sender || parcel.barcode || 'PostNL', barcode: parcel.barcode || '', status,
      status_raw: statusRaw,
      status_code: String(parcel.statusCode || ''),
      status_event: String(parcel.latestStatusEvent || statusRaw || ''),
      status_event_time: statusEventTime,
      delivery_date: deliveryDate, delivery_window: deliveryWindow,
      delivery_window_from: parcel.deliveryWindowFrom ? this.api.formatTime(parcel.deliveryWindowFrom) : '',
      delivery_window_to: parcel.deliveryWindowTo ? this.api.formatTime(parcel.deliveryWindowTo) : '',
      delivery_window_type: parcel.deliveryWindowType || '', details_url: parcel.detailsUrl || '', shipment_type: parcel.shipmentType || '',
      delivery_address_type: parcel.deliveryAddressType || '', direction: parcel.direction || '',
      created_at: parcel.createdAt ? this.api.formatDateTime(parcel.createdAt) : '',
      delivered: Boolean(parcel.delivered), shared_from: parcel.sourceDisplayName || '', source_account_id: parcel.sourceAccountId || '',
      package_status_text: status, package_window_text: deliveryWindow, package_delivery_date: deliveryDate,
      package_sender: sender, package_tracking: tracking,
      weight: Number.isFinite(Number(parcel.weightKg)) ? Number(parcel.weightKg) : 0,
      dimensions: String(parcel.dimensionsText || ''),
      status_history: String(parcel.statusHistoryText || ''),
      observation_code: String(parcel.observationCode || ''),
      canonical_status: String(parcel.canonicalStatus || ''),
      pickup: Boolean(parcel.pickup),
      pickup_type: String(parcel.pickupType || parcel.deliveryAddressType || ''),
      package_image_available: Boolean(packageImage),
    };
    if (packageImage) tokens.package_image = packageImage;
    return tokens;
  }

  async _mailTokens(letter = {}, count = 1) {
    const image = await this.getLetterImage(letter).catch(() => null);
    const tokens = {
      count: Number(count || 0), id: letter.id || '', title: letter.title || '', sender: letter.sender || '',
      date: letter.deliveryDate ? this.api.formatDate(letter.deliveryDate) : '', unread: Boolean(letter.unread), image_available: Boolean(image),
    };
    if (image) tokens.image = image;
    return tokens;
  }

  _hasDeliveryWindow(parcel = {}) {
    return Boolean(
      String(parcel.deliveryWindow || '').trim()
      || String(parcel.deliveryWindowFrom || '').trim()
      || String(parcel.deliveryWindowTo || '').trim()
    );
  }

  _packageStatusFingerprint(parcel = {}) {
    return String(parcel.statusFingerprint || [
      parcel.statusRaw || parcel.status || '',
      parcel.statusCode || '',
      parcel.statusChangedAt || '',
      parcel.latestStatusEvent || '',
      parcel.deliveryWindow || '',
      parcel.deliveryDate || '',
    ].join('|'));
  }

  async handleSnapshotChanges(previous = {}, current = {}) {
    const previousLiveLetters = Array.isArray(previous.liveLetters) ? previous.liveLetters : (previous.letters || []);
    const todayKey = this._localDateKey();
    const currentLiveLetters = (current.liveLetters || []).filter(item => {
      const key = this._localDateKey(item.deliveryDate);
      return key && key >= todayKey;
    });
    const previousCurrentLetters = previousLiveLetters.filter(item => {
      const key = this._localDateKey(item.deliveryDate);
      return key && key >= todayKey;
    });
    const oldLetterIds = new Set(previousCurrentLetters.map(item => item.id));
    const newLetters = currentLiveLetters.filter(item => !oldLetterIds.has(item.id));
    const oldPackages = new Map((previous.packages || []).map(item => [item.id, item]));

    // On the first successful sync after install/upgrade, seed a baseline rather
    // than firing every existing PostNL item as if it had just appeared.
    if (this.getStoreValue('flowBaselineInitialized') !== true) {
      await this.setStoreValue('flowBaselineInitialized', true);
      this.log('[FlowTrigger] baseline initialized; existing mail/parcels suppressed once');
      return;
    }

    if (newLetters.length) {
      const newest = [...newLetters].sort((a, b) => new Date(b.deliveryDate || 0) - new Date(a.deliveryDate || 0))[0];
      await this.triggerNewMail(await this._mailTokens(newest, newLetters.length));
    }
    for (const parcel of current.packages || []) {
      const old = oldPackages.get(parcel.id);
      const tokens = await this._packageTokens(parcel);
      if (!old) await this.triggerNewPackage(tokens);

      const hasWindow = !parcel.delivered && this._hasDeliveryWindow(parcel);
      const hadWindow = Boolean(old && !old.delivered && this._hasDeliveryWindow(old));
      if (hasWindow && !hadWindow) await this.triggerDeliveryWindowKnown(tokens);

      if (old && this._packageStatusFingerprint(old) !== this._packageStatusFingerprint(parcel)) {
        await this.triggerPackageStatusChanged({
          ...tokens,
          old_status: String(old.statusRaw || localizePackageStatus(this.homey, old.status) || old.status || ''),
        });
      }
    }

    // A parcel can disappear from the account list immediately after delivery.
    // Refresh such a previously active parcel once via Track & Trace so the final
    // official status (for example "Bezorgd") is not missed by the Flow trigger.
    const currentIds = new Set((current.packages || []).map(item => item.id));
    for (const old of oldPackages.values()) {
      if (currentIds.has(old.id) || old.delivered || !old.detailsUrl) continue;
      try {
        const refreshed = await this.api.refreshPackageTracking(old);
        if (this._packageStatusFingerprint(old) !== this._packageStatusFingerprint(refreshed)) {
          const tokens = await this._packageTokens(refreshed);
          await this.triggerPackageStatusChanged({
            ...tokens,
            old_status: String(old.statusRaw || localizePackageStatus(this.homey, old.status) || old.status || ''),
          });
        }
      } catch (error) {
        this.log('Final PostNL status refresh failed', old.barcode || old.id, error.message);
      }
    }
  }


  async _updateGlobalSnapshotTokens(snapshot = {}) {
    const letters = Array.isArray(snapshot.liveLetters) ? snapshot.liveLetters : [];
    const packages = (snapshot.packages || []).filter(item => !item.delivered);
    const newestMail = [...letters].sort((a, b) => new Date(b.deliveryDate || 0) - new Date(a.deliveryDate || 0))[0] || {};
    const activePackage = this._selectActivePackage(snapshot) || {};
    const status = activePackage.id ? String(activePackage.statusRaw || activePackage.latestStatusEvent || activePackage.status || '').trim() : '';
    const deliveryDate = activePackage.deliveryDate ? this.api.formatDateDMY(activePackage.deliveryDate) : '';
    const deliveryWindow = activePackage.deliveryWindow || this.api.formatWindow(activePackage.deliveryWindowFrom, activePackage.deliveryWindowTo) || '';
    const dates = [...letters.map(item => item.deliveryDate).filter(Boolean), ...packages.map(item => item.deliveryDate).filter(Boolean)].sort((a, b) => new Date(a) - new Date(b));
    const connected = this.api.hasCredentials();
    await this._flowDriver().updateGlobalTokens(this, {
      mail_expected: letters.length > 0, mail_count: letters.length, mail_id: newestMail.id || '', mail_title: newestMail.title || '', mail_sender: newestMail.sender || '', mail_date: newestMail.deliveryDate ? this.api.formatDate(newestMail.deliveryDate) : '', mail_unread: Boolean(newestMail.unread),
      package_count: packages.length, package_id: activePackage.id || '', package_sender: activePackage.sender || activePackage.title || '', package_receiver: activePackage.receiver || '', package_title: activePackage.title || activePackage.sender || activePackage.barcode || '', package_barcode: activePackage.barcode || '', package_status: status, package_status_raw: status, package_status_code: activePackage.statusCode || '', package_status_event: activePackage.latestStatusEvent || status, package_status_event_time: activePackage.statusChangedAt ? (this.api.formatDateTime(activePackage.statusChangedAt) || String(activePackage.statusChangedAt)) : '', package_delivery_date: deliveryDate, package_delivery_window: deliveryWindow, package_delivery_window_from: activePackage.deliveryWindowFrom ? this.api.formatTime(activePackage.deliveryWindowFrom) : '', package_delivery_window_to: activePackage.deliveryWindowTo ? this.api.formatTime(activePackage.deliveryWindowTo) : '', package_delivery_window_type: activePackage.deliveryWindowType || '', package_details_url: activePackage.detailsUrl || '', package_shipment_type: activePackage.shipmentType || '', package_delivery_address_type: activePackage.deliveryAddressType || '', package_direction: activePackage.direction || '', package_created_at: activePackage.createdAt ? this.api.formatDateTime(activePackage.createdAt) : '', package_delivered: Boolean(activePackage.delivered), package_shared_from: activePackage.sourceDisplayName || '', package_source_account_id: activePackage.sourceAccountId || '', package_tracking: activePackage.barcode || activePackage.id || '', package_weight: Number.isFinite(Number(activePackage.weightKg)) ? Number(activePackage.weightKg) : 0, package_dimensions: activePackage.dimensionsText || '', package_status_history: activePackage.statusHistoryText || '', package_observation_code: activePackage.observationCode || '', package_canonical_status: activePackage.canonicalStatus || '', package_pickup: Boolean(activePackage.pickup), package_pickup_type: activePackage.pickupType || activePackage.deliveryAddressType || '', next_delivery: dates[0] ? this.api.formatDate(dates[0]) : '', connection_status: connected ? (this.homey.i18n.getLanguage() === 'nl' ? 'Verbonden' : 'Connected') : (this.homey.i18n.getLanguage() === 'nl' ? 'Niet verbonden' : 'Not connected'), last_update: snapshot.updatedAt ? this.api.formatDateTime(snapshot.updatedAt) : '',
    });
  }

  _parseLocalOrZonedParts(value) {
    const raw = String(value || '').trim();
    if (!raw) return null;
    const hasZone = /(?:Z|[+-]\d{2}:?\d{2})$/i.test(raw);
    const localMatch = raw.match(/^(\d{4})-(\d{2})-(\d{2})[T\s](\d{2}):(\d{2})/);
    if (localMatch && !hasZone) {
      const [, year, month, day, hour, minute] = localMatch;
      return {
        date: `${year}-${month}-${day}`,
        minutes: Number(hour) * 60 + Number(minute),
        time: `${hour}:${minute}`,
      };
    }
    const date = new Date(raw);
    if (Number.isNaN(date.getTime())) return null;
    const parts = new Intl.DateTimeFormat('en-CA', {
      timeZone: this.homey.clock.getTimezone(),
      year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false,
    }).formatToParts(date);
    const get = type => parts.find(part => part.type === type)?.value || '';
    return {
      date: `${get('year')}-${get('month')}-${get('day')}`,
      minutes: Number(get('hour')) * 60 + Number(get('minute')),
      time: `${get('hour')}:${get('minute')}`,
    };
  }

  _nowLocalParts() {
    const parts = new Intl.DateTimeFormat('en-CA', {
      timeZone: this.homey.clock.getTimezone(),
      year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false,
    }).formatToParts(new Date());
    const get = type => parts.find(part => part.type === type)?.value || '0';
    const hour = Number(get('hour'));
    const minute = Number(get('minute'));
    const second = Number(get('second'));
    return {
      date: `${get('year')}-${get('month')}-${get('day')}`,
      seconds: (hour * 3600) + (minute * 60) + second,
    };
  }

  _deliveryHeadline(parcel = {}, language = 'nl') {
    const fromParts = this._parseLocalOrZonedParts(parcel.deliveryWindowFrom);
    const toParts = this._parseLocalOrZonedParts(parcel.deliveryWindowTo);
    const dateKey = fromParts?.date || this._localDateKey(parcel.deliveryDate);
    const todayKey = this._localDateKey();
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const tomorrowKey = this._localDateKey(tomorrow);
    if (fromParts?.time && toParts?.time) {
      if (dateKey === todayKey) return language === 'nl' ? `Vandaag tussen ${fromParts.time} en ${toParts.time}` : `Today between ${fromParts.time} and ${toParts.time}`;
      if (dateKey === tomorrowKey) return language === 'nl' ? `Morgen tussen ${fromParts.time} en ${toParts.time}` : `Tomorrow between ${fromParts.time} and ${toParts.time}`;
      const dateText = parcel.deliveryDate ? this.api.formatDate(parcel.deliveryDate) : dateKey;
      return language === 'nl' ? `${dateText} tussen ${fromParts.time} en ${toParts.time}` : `${dateText} between ${fromParts.time} and ${toParts.time}`;
    }
    if (parcel.deliveryWindow) return parcel.deliveryWindow;
    if (parcel.deliveryDate) return this.api.formatDate(parcel.deliveryDate);
    return language === 'nl' ? 'Pakket onderweg' : 'Parcel on the way';
  }

  _selectActivePackage(snapshot = this.snapshot) {
    return [...((snapshot && snapshot.packages) || [])]
      .filter(item => !item.delivered)
      .sort((a, b) => {
        const left = Date.parse(a.deliveryWindowFrom || a.deliveryDate || a.createdAt || '') || Number.MAX_SAFE_INTEGER;
        const right = Date.parse(b.deliveryWindowFrom || b.deliveryDate || b.createdAt || '') || Number.MAX_SAFE_INTEGER;
        return left - right;
      })[0] || null;
  }

  async _ensurePackageCameraImage() {
    if (this._packageCameraImage) return this._packageCameraImage;
    this._packageCameraImage = await this.homey.images.createImage();
    this._packageCameraImage.setStream(async stream => {
      if (!this._packageImageBuffer?.length) await this._refreshPackageImageBuffer(true);
      const buffer = this._packageImageBuffer;
      if (!buffer?.length) throw new Error('PostNL delivery PNG buffer is empty');
      stream.contentType = 'image/png';
      stream.filename = 'postnl-my-delivery.png';
      stream.end(buffer);
      return stream;
    });
    const language = this.homey.i18n.getLanguage() === 'nl' ? 'nl' : 'en';
    await this.setCameraImage('latest_package', language === 'nl' ? 'Mijn Bezorging' : 'My Delivery', this._packageCameraImage);
    return this._packageCameraImage;
  }

  _startPackageImageRefresh() {
    if (this._packageImageTimer) this.homey.clearInterval(this._packageImageTimer);
    this._packageImageTimer = this.homey.setInterval(() => {
      if (this._activePackageForImage) this._refreshPackageImageBuffer().catch(this.error);
    }, 15000);
  }

  async _refreshPackageImageBuffer(force = false, parcel = undefined) {
    const activePackage = parcel === undefined ? (this._activePackageForImage || this._selectActivePackage()) : parcel;
    this._activePackageForImage = activePackage || null;
    const language = this.homey.i18n.getLanguage() === 'nl' ? 'nl' : 'en';
    if (!activePackage) {
      this._packageImageBuffer = renderNoPackageCard({ language, vanPng: loadDeliveryVan() });
      return this._packageImageBuffer;
    }

    const from = this._parseLocalOrZonedParts(activePackage.deliveryWindowFrom);
    const to = this._parseLocalOrZonedParts(activePackage.deliveryWindowTo);
    let progress = 0;
    let windowStartPct = 0.25;
    let windowEndPct = 0.75;
    let timelineStart = '';
    let timelineMid = '';
    let timelineEnd = '';
    if (from && to) {
      const displayStart = from.minutes - 60;
      const displayEnd = to.minutes + 60;
      const spanMinutes = Math.max(1, displayEnd - displayStart);
      windowStartPct = (from.minutes - displayStart) / spanMinutes;
      windowEndPct = (to.minutes - displayStart) / spanMinutes;
      timelineStart = hhmm(displayStart);
      timelineMid = hhmm(Math.round((displayStart + displayEnd) / 2));
      timelineEnd = hhmm(displayEnd);
      const now = this._nowLocalParts();
      if (now.date < from.date) progress = 0;
      else if (now.date > from.date) progress = 1;
      else {
        const startSeconds = displayStart * 60;
        const endSeconds = displayEnd * 60;
        progress = Math.max(0, Math.min(1, (now.seconds - startSeconds) / Math.max(1, endSeconds - startSeconds)));
      }
    }

    const status = String(activePackage.statusRaw || activePackage.latestStatusEvent || activePackage.status || localizePackageStatus(this.homey, activePackage.status) || '').trim();
    const sender = activePackage.sender || activePackage.title || activePackage.sourceDisplayName || 'PostNL';
    const tracking = activePackage.barcode || activePackage.id || '';
    const headline = this._deliveryHeadline(activePackage, language);
    const vanPng = loadDeliveryVan();
    this._packageImageBuffer = renderDeliveryCard({
      sender, status, headline, tracking, progress, windowStartPct, windowEndPct,
      timelineStart, timelineMid, timelineEnd, vanPng,
    });
    return this._packageImageBuffer;
  }

  async getPackageDeliveryImage(parcel = null) {
    const image = await this._ensurePackageCameraImage();
    await this._refreshPackageImageBuffer(true, parcel || this._selectActivePackage());
    return image;
  }

  async getLetterImage(letter) {
    if (!letter?.imageData || !String(letter.imageData).startsWith('data:')) return null;
    const cacheKey = `${letter.id || 'mail'}:${letter.imageData.length}`;
    if (this._letterImageCache.has(cacheKey)) return this._letterImageCache.get(cacheKey);
    const match = String(letter.imageData).match(/^data:([^;]+);base64,(.+)$/s);
    if (!match) return null;
    const buffer = Buffer.from(match[2], 'base64');
    if (!buffer.length) return null;
    const image = await this.homey.images.createImage();
    image.setStream(async stream => {
      stream.contentType = match[1] || 'image/jpeg';
      stream.filename = `postnl-${String(letter.id || 'mail').replace(/[^a-zA-Z0-9_-]/g, '_')}.jpg`;
      stream.end(buffer);
      return stream;
    });
    this._letterImageCache.set(cacheKey, image);
    if (this._letterImageCache.size > 25) this._letterImageCache.delete(this._letterImageCache.keys().next().value);
    return image;
  }

  async getNoMailPlaceholderImage() {
    const language = this.homey.i18n.getLanguage() === 'nl' ? 'nl' : 'en';
    const cacheKey = `no-mail-placeholder:${language}`;
    if (this._letterImageCache.has(cacheKey)) return this._letterImageCache.get(cacheKey);

    const filePath = path.join(__dirname, '..', '..', 'assets', `no-mail-${language}.png`);
    const buffer = await fs.promises.readFile(filePath);
    if (!buffer?.length) throw new Error('PostNL fallback image is empty');

    const image = await this.homey.images.createImage();
    image.setStream(async stream => {
      stream.contentType = 'image/png';
      stream.filename = `postnl-no-mail-${language}.png`;
      stream.end(buffer);
      return stream;
    });
    this._letterImageCache.set(cacheKey, image);
    return image;
  }

  async _imageFromFile(cache, cacheKey, filePath, contentType, filename) {
    if (cache.has(cacheKey)) return cache.get(cacheKey);
    const buffer = await fs.promises.readFile(filePath);
    if (!buffer?.length) throw new Error(`PostNL image is empty: ${filename}`);
    const image = await this.homey.images.createImage();
    image.setStream(async stream => {
      stream.contentType = contentType;
      stream.filename = filename;
      stream.end(buffer);
      return stream;
    });
    cache.set(cacheKey, image);
    return image;
  }

  async getPackageVanImage() {
    return this.getPackageDeliveryImage(this._selectActivePackage());
  }

  async getNoPackagePlaceholderImage() {
    const language = this.homey.i18n.getLanguage() === 'nl' ? 'nl' : 'en';
    const cacheKey = `no-package:${language}`;
    if (this._packageImageCache.has(cacheKey)) return this._packageImageCache.get(cacheKey);
    const buffer = renderNoPackageCard({ language, vanPng: loadDeliveryVan() });
    const image = await this.homey.images.createImage();
    image.setStream(async stream => {
      stream.contentType = 'image/png';
      stream.filename = `postnl-no-package-${language}.png`;
      stream.end(buffer);
      return stream;
    });
    this._packageImageCache.set(cacheKey, image);
    return image;
  }

  _localDateKey(value = new Date()) {
    const date = value instanceof Date ? value : new Date(value);
    if (Number.isNaN(date.getTime())) return '';
    const parts = new Intl.DateTimeFormat('en-CA', {
      timeZone: this.homey.clock.getTimezone(), year: 'numeric', month: '2-digit', day: '2-digit',
    }).formatToParts(date);
    const get = type => parts.find(part => part.type === type)?.value || '';
    return `${get('year')}-${get('month')}-${get('day')}`;
  }

  async applySnapshot(snapshot = {}, error = null) {
    // Only mail currently returned by PostNL drives device capabilities and images.
    const letters = Array.isArray(snapshot.liveLetters) ? snapshot.liveLetters : [];
    const packages = (snapshot.packages || []).filter(item => !item.delivered);
    const todayKey = this._localDateKey();
    const currentMail = letters.filter(item => {
      const key = this._localDateKey(item.deliveryDate);
      return key && key >= todayKey;
    });
    const mailDates = currentMail.map(item => item.deliveryDate).filter(Boolean);
    const packageDates = packages.map(item => item.deliveryDate).filter(Boolean).filter(value => this._localDateKey(value) >= todayKey);
    const dates = [...mailDates, ...packageDates].sort((a, b) => new Date(a) - new Date(b));
    const nextDelivery = dates[0] ? this.api.formatDate(dates[0]) : '—';
    const nextPackage = [...packages]
      .filter(item => item.deliveryDate || item.deliveryWindowFrom || item.deliveryWindowTo)
      .sort((a, b) => {
        const left = Date.parse(a.deliveryWindowFrom || a.deliveryDate || a.createdAt || '') || Number.MAX_SAFE_INTEGER;
        const right = Date.parse(b.deliveryWindowFrom || b.deliveryDate || b.createdAt || '') || Number.MAX_SAFE_INTEGER;
        return left - right;
      })[0] || null;
    const packageDeliveryDate = nextPackage?.deliveryDate || nextPackage?.deliveryWindowFrom || nextPackage?.deliveryWindowTo || null;
    const packageDeliveryWindow = nextPackage?.deliveryWindow || this.api.formatWindow(nextPackage?.deliveryWindowFrom, nextPackage?.deliveryWindowTo) || '';
    const updated = snapshot.updatedAt
      ? new Intl.DateTimeFormat(this.homey.i18n.getLanguage() === 'nl' ? 'nl-NL' : 'en-GB', { timeZone: this.homey.clock.getTimezone(), dateStyle: 'short', timeStyle: 'short' }).format(new Date(snapshot.updatedAt))
      : '—';
    const connected = this.api.hasCredentials();
    const officialPackageStatus = nextPackage ? String(nextPackage.statusRaw || nextPackage.latestStatusEvent || nextPackage.status || '') : '—';
    const values = {
      postnl_mail_expected: currentMail.length > 0, postnl_mail_count: currentMail.length, postnl_package_count: packages.length, postnl_next_delivery: nextDelivery,
      postnl_delivery_date: packageDeliveryDate ? this.api.formatDateDMY(packageDeliveryDate) : '—', postnl_delivery_window: packageDeliveryWindow || '—',
      postnl_package_status: officialPackageStatus, postnl_package_sender: nextPackage ? String(nextPackage.sender || nextPackage.title || nextPackage.sourceDisplayName || '—') : '—', postnl_package_receiver: nextPackage ? String(nextPackage.receiver || '—') : '—', postnl_package_tracking: nextPackage ? String(nextPackage.barcode || nextPackage.id || '—') : '—', postnl_package_event: nextPackage ? String(nextPackage.latestStatusEvent || nextPackage.statusRaw || nextPackage.status || '—') : '—', postnl_package_status_time: nextPackage?.statusChangedAt ? (this.api.formatDateTime(nextPackage.statusChangedAt) || String(nextPackage.statusChangedAt)) : '—', postnl_package_delivered: Boolean(nextPackage?.delivered), postnl_package_shipment_type: nextPackage?.shipmentType || '—',
      postnl_package_weight: nextPackage && Number.isFinite(Number(nextPackage.weightKg)) ? Number(nextPackage.weightKg) : 0,
      postnl_package_dimensions: nextPackage?.dimensionsText || '—',
      postnl_package_history: nextPackage?.statusHistoryText || '—',
      postnl_package_observation_code: nextPackage?.observationCode || '—',
      postnl_package_canonical_status: nextPackage?.canonicalStatus || '—',
      postnl_package_pickup: Boolean(nextPackage?.pickup),
      postnl_package_pickup_type: nextPackage?.pickupType || nextPackage?.deliveryAddressType || '—',
      postnl_status: connected ? (this.homey.i18n.getLanguage() === 'nl' ? 'Verbonden' : 'Connected') : (this.homey.i18n.getLanguage() === 'nl' ? 'Niet verbonden' : 'Not connected'), postnl_last_update: updated,
    };
    for (const [capability, value] of Object.entries(values)) if (this.hasCapability(capability)) await this.setCapabilityValue(capability, value).catch(this.error);

    const language = this.homey.i18n.getLanguage() === 'nl' ? 'nl' : 'en';
    const imageTitle = language === 'nl' ? 'Laatste poststuk' : 'Latest mail item';
    const latestWithImage = [...currentMail]
      .sort((a, b) => new Date(b.deliveryDate || 0) - new Date(a.deliveryDate || 0))
      .find(item => item?.imageData);
    if (latestWithImage && latestWithImage.id !== this._latestMailImageId) {
      const image = await this.getLetterImage(latestWithImage).catch(() => null);
      if (image) {
        await this.setCameraImage('latest_mail_item', imageTitle, image);
        this._latestMailImageId = latestWithImage.id;
      }
    }
    if (!latestWithImage) {
      const placeholderId = `__no_mail__:${language}`;
      if (this._latestMailImageId !== placeholderId) {
        const image = await this.getNoMailPlaceholderImage().catch(() => null);
        if (image) {
          await this.setCameraImage('latest_mail_item', imageTitle, image);
          this._latestMailImageId = placeholderId;
        }
      }
    }
    const activePackage = this._selectActivePackage(snapshot);
    this._activePackageForImage = activePackage;
    await this._ensurePackageCameraImage().catch(this.error);
    await this._refreshPackageImageBuffer(true, activePackage).catch(this.error);
    await this._updateGlobalSnapshotTokens(snapshot).catch(error => this.error('[GlobalToken] snapshot update failed', error));


    if (error) await this.setUnavailable(error.message).catch(this.error);
    else await this.setAvailable().catch(this.error);
  }

  isMailExpected() { return Boolean(this.getCapabilityValue('postnl_mail_expected')); }
  hasPackagesUnderway() { return Number(this.getCapabilityValue('postnl_package_count') || 0) > 0; }
  hasDeliveryWindowKnown() { return (this.snapshot.packages || []).some(parcel => !parcel.delivered && this._hasDeliveryWindow(parcel)); }

  getWidgetData() {
    return {
      authenticated: this.api.hasCredentials(),
      // My Post is live-only; no local mail history is exposed or retained.
      letters: (this.snapshot.liveLetters || []).slice(0, 60),
      liveLetters: (this.snapshot.liveLetters || []).slice(0, 60),
      packages: (this.snapshot.packages || []).slice(0, 40),
      updatedAt: this.snapshot.updatedAt || null, mailApiStatus: this.snapshot.mailApiStatus || 'unknown', mailApiError: this.snapshot.mailApiError || null,
    };
  }
}

module.exports = PostNLDevice;
